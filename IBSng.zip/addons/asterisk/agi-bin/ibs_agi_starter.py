#!/usr/bin/python
import ibs_agi
ibs_agi.init()
#digits=ibs_agi.getLangManager().getLanguage("fa").sayFilesAndCollect("1",8)
#ibs_agi.getLangManager().getLanguage("fa").sayNumber(digits)
