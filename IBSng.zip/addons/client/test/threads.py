from core.threadpool import threadpool
tpool=threadpool.getThreadPool()
print str(tpool)