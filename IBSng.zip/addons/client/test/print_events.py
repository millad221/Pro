from core.event import event
event.sched.printMe()