from core.group import group_main
print str(group_main.getLoader().groups_name)