insert into defs (name,value) VALUES ('KILL_USERS_ON_SHUTDOWN','I1
.') ;
insert into defs (name,value) VALUES ('KILL_USERS_SHUTDOWN_WAIT_TIME','I5
.') ;
