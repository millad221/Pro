insert into defs (name,value) VALUES ('REALTIME_BW_SNAPSHOT_HOURS','I5
.') ;
insert into defs (name,value) VALUES ('REALTIME_BW_SNAPSHOT_INTERVAL','I15
.') ;
insert into defs (name,value) VALUES ('REALTIME_ONLINES_SNAPSHOT_HOURS','I5
.') ;
insert into defs (name,value) VALUES ('REALTIME_ONLINES_SNAPSHOT_INTERVAL','I15
.') ;
insert into defs (name,value) VALUES ('SNAPSHOT_BW_INTERVAL','I60
.') ;
insert into defs (name,value) VALUES ('SNAPSHOT_ONLINES_INTERVAL','I300
.') ;
