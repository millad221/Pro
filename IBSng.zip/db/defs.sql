insert into defs (name,value) VALUES ('BW_IPTABLES_COMMAND','S\'iptables\'
p0
.') ;
insert into defs (name,value) VALUES ('BW_TC_COMMAND','S\'tc\'
p0
.') ;
insert into defs (name,value) VALUES ('CHECK_ONLINE_INTERVAL','I60
.') ;
insert into defs (name,value) VALUES ('CHECK_ONLINE_MAX_FAILS','I2
.') ;
insert into defs (name,value) VALUES ('IAS_ENABLED','I0
.') ;
insert into defs (name,value) VALUES ('IBS_SERVER_IP','S\'127.0.0.1\'
p0
.') ;
insert into defs (name,value) VALUES ('IBS_SERVER_PORT','I1235
.') ;
insert into defs (name,value) VALUES ('KILL_USERS_ON_SHUTDOWN','I1
.') ;
insert into defs (name,value) VALUES ('KILL_USERS_SHUTDOWN_WAIT_TIME','I20
.') ;
insert into defs (name,value) VALUES ('MAX_USER_POOL_SIZE','I10000
.') ;
insert into defs (name,value) VALUES ('RADIUS_SERVER_ACCT_PORT','I1813
.') ;
insert into defs (name,value) VALUES ('RADIUS_SERVER_AUTH_PORT','I1812
.') ;
insert into defs (name,value) VALUES ('RADIUS_SERVER_BIND_IP','(lp0
S\'0.0.0.0\'
p1
a.') ;
insert into defs (name,value) VALUES ('RADIUS_SERVER_ENABLED','I1
.') ;
insert into defs (name,value) VALUES ('REALTIME_BW_SNAPSHOT_HOURS','I5
.') ;
insert into defs (name,value) VALUES ('REALTIME_BW_SNAPSHOT_INTERVAL','I15
.') ;
insert into defs (name,value) VALUES ('REALTIME_ONLINES_SNAPSHOT_HOURS','I5
.') ;
insert into defs (name,value) VALUES ('REALTIME_ONLINES_SNAPSHOT_INTERVAL','I15
.') ;
insert into defs (name,value) VALUES ('SNAPSHOT_BW_INTERVAL','I60
.') ;
insert into defs (name,value) VALUES ('SNAPSHOT_ONLINES_INTERVAL','I300
.') ;
insert into defs (name,value) VALUES ('TRUSTED_CLIENTS','(lp0
S\'127.0.0.1\'
p1
a.') ;
insert into defs (name,value) VALUES ('USER_AUDIT_LOG','I1
.') ;
insert into defs (name,value) VALUES ('WEB_ANALYZER_PASSWORD','S\'web_analyzer_password\'
p0
.') ;
