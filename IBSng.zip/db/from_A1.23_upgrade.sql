alter table tariff_prefix_list drop CONSTRAINT tariff_prefix_list_prefix_code_key;
insert into defs (name,value) VALUES ('RADIUS_SERVER_CLEANUP_TIME','I20
.') ;
insert into defs (name,value) VALUES ('FASTDIAL_PREFIX','S\'\'
p0
.') ;
 